<?php
//项目配置文件
//session_start();
require_once "Facebook/autoload.php";
$FB = new \Facebook\Facebook([
    'app_id' => '189086645069783',
    'app_secret' => '8ef3b7c855020996cb54f87060dee360',
    'default_graph_version' => 'v2.10'
]);

$helper = $FB->getRedirectLoginHelper();
?>